/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "usb_host.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//#include "cmsis_os.h"
//#include "usb_host.h"
//#include "cmsis_os2.h"
#include "stdio.h"
#include <math.h>
#include <stdlib.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

DMA2D_HandleTypeDef hdma2d;

I2C_HandleTypeDef hi2c3;

LTDC_HandleTypeDef hltdc;

RNG_HandleTypeDef hrng;

SPI_HandleTypeDef hspi5;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart1;

SDRAM_HandleTypeDef hsdram2;

/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 4096 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
static void MX_GPIO_Init(void);
static void MX_CRC_Init(void);
static void MX_DMA2D_Init(void);
static void MX_FMC_Init(void);
static void MX_I2C3_Init(void);
static void MX_LTDC_Init(void);
static void MX_SPI5_Init(void);
static void MX_TIM1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_RNG_Init(void);
void StartDefaultTask(void *argument);

/* USER CODE BEGIN PFP */

static void SystemClock_Config(void);
void GyroMonitorTaskCallback (void *argument);
void ButtonInputTaskCallback (void *argument);
void DroneTaskCallback (cell** maze);
void LEDOutputTaskCallback (void *argument);
void LCDUpdateTaskCallback (cell** maze);


#define PI (3.141592653589793)



/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

osThreadId_t MazeGenerationTask, GyroMonitorTask, ButtonInputTask, DroneTask, LEDOutputTask, LCDUpdateTask;     // gyro monitor task
uint32_t randVal; //value to be passed as pointer to RNG
int digit;//variable to store last digit of randVal
static osSemaphoreId_t gyroSemaphore, buttonSemaphore, LCDSemaphore, LEDSemaphore, systemTimerSemaphore, droneSemaphore;            // semaphore id global variable

static osTimerId_t  SystemTimer, gyroTimer; //got rid of gyro timer

enum pinCenter {DRONE, MAZE};  //enum to store the pin at center value


float xPos = 40;
float yPos = 40;
uint16_t xVel = 0;
uint16_t yVel = 0;

int16_t gyroXVal = 0;
int16_t gyroYVal = 0;
bool isPressed; //variable to store whether the button is pressed
int time;
float pressedTime;

static StaticTimer_t TCB, TCB2; //timer

// Attributes structure for gyro timer.
const osTimerAttr_t GyroTimerAttributes = {
		.name = "gyroTimer",
		.cb_mem = &TCB2,
		.cb_size = sizeof(TCB2)
};

// Attributes structure for timer.
const osTimerAttr_t SystemTimerAttributes = {
		.name = "systemTimer",
		.cb_mem = &TCB,
		.cb_size = sizeof(TCB)
};



IntegerPair intPair1;
IntegerPair intPair2;
IntegerPair intPair3;
IntegerPair intPair4;

bool waypoint1Hit = false;
bool waypoint2Hit = false;
bool waypoint3Hit = false;
bool waypoint4Hit = false;

bool isOver = false; //if the game is over or not
int disruptorPower; //disruptor power

init defaultValues;
mazeVal defaultMaze;

cell* walls;
cell* holes;
int numWalls = 0;
int numHoles = 0;


int printY;
int printX;


void GyroTimerCallback (void* arg){

	//printf("gonna release gyroSemaphore");

	osSemaphoreRelease(gyroSemaphore);
}

void SystemTimerCallback(void* arg){

	time--;
	if(time == 0){
		timeEnded();
	}
	if(isPressed){
		pressedTime++;
	}

}



/* USER CODE END 0 */




/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	extern void initialise_monitor_handles(void);

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CRC_Init();
  MX_DMA2D_Init();
  MX_FMC_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_SPI5_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  MX_RNG_Init();
  /* USER CODE BEGIN 2 */


  Application_Init();
  initialise_monitor_handles();
  displayMenu();
  setDefaultValues();
  cell** maze = generateMaze(3, defaultValues.width, defaultValues.height, defaultMaze.hardEdged);
  walls = getWallList(maze, defaultValues.width, defaultValues.height);
  holes = getHoleList(maze, defaultValues.width, defaultValues.height); //here use the default values
  for(int i = 0; i < defaultValues.width; i++){
	  for(int j = 0; j < defaultValues.height; j++){
		  if(maze[i][j].isHole){
			  numHoles++;
		  }
		  if(maze[i][j].isWall){
			  numWalls++;
		  }
	  }
  }


  time = defaultValues.timeToComplete;
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
	gyroSemaphore = osSemaphoreNew(1U, 0, NULL);
	buttonSemaphore = osSemaphoreNew(1U, 0, NULL);
	LCDSemaphore = osSemaphoreNew(1U, 0, NULL);
	LEDSemaphore = osSemaphoreNew(1U, 0, NULL);
	systemTimerSemaphore = osSemaphoreNew(1U, 0, NULL);
	droneSemaphore = osSemaphoreNew(1U, 0, NULL);  /* USER CODE END RTOS_SEMAPHORES */


  /* USER CODE BEGIN RTOS_TIMERS */
	uint32_t exec = 1U;
	uint32_t exec2 = 1U;

	osStatus_t status; // function return status
	disruptorPower = defaultValues.power;

	SystemTimer = osTimerNew (SystemTimerCallback, osTimerPeriodic, &exec2, &SystemTimerAttributes);
	if (SystemTimer != NULL)  {
	    status = osTimerStart(SystemTimer, 100);       // start timer
	    if (status != osOK) {
	      // Timer could not be started
	    }
	}

	gyroTimer = osTimerNew(GyroTimerCallback, osTimerPeriodic , &exec, &GyroTimerAttributes);
	if (gyroTimer != NULL)  {
	    status = osTimerStart(gyroTimer, 100);       // start timer
	    if (status != osOK) {
	      // Timer could not be started
	    }
	}  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
   defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
//
	GyroMonitorTask = osThreadNew(GyroMonitorTaskCallback, NULL, NULL); //pass in parameter for the maze size
	ButtonInputTask = osThreadNew(ButtonInputTaskCallback, NULL, NULL); //pass in parameter for the maze size
	DroneTask = osThreadNew(DroneTaskCallback, maze, NULL); //pass in parameter for the maze size
	LEDOutputTask = osThreadNew(LEDOutputTaskCallback, NULL, NULL); //pass in parameter for the maze size
	LCDUpdateTask  = osThreadNew(LCDUpdateTaskCallback, maze, NULL); //pass in parameter for the maze size


  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


/**
  * @brief  System Clock Configuration
  *         configured as follows :
  *            System Clock source - PLL
  *            SYSCLK - 168000000
  *            HCLK - 168000000
  *			   Prescalers:
  *            		AHB - 1
  *            		APB1 - 4
  *            		APB2 - 2
  *            HSE - 8000000
  *            PLL:
  *            		M - 8
  *            		N - 336
  *            		P - 2
  *            		Q - 7
  * @param  None
  * @retval None
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the device is
     clocked below the maximum system frequency, to update the voltage scaling value
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}



void GyroMonitorTaskCallback (void *argument){
//	  (void) &argument; //remove warnings for unused variables


	  for(;;)
	  {
		osSemaphoreAcquire(gyroSemaphore ,osWaitForever);
		gyroYVal = Gyro_Get_Velocity();
		//printf("Y Velocity: %d\n", gyroYVal);
		gyroXVal = Gyro_Get_VelocityX();
		//printf("X Velocity: %d\n", gyroXVal);
		//osSemaphoreRelease(gyroSemaphore);
		osSemaphoreRelease(droneSemaphore);
	  }
}


void ButtonInputTaskCallback (void *argument){
	  (void) &argument; //remove warnings for unused variables

	  for(;;)
	  {
		osSemaphoreAcquire(	buttonSemaphore ,osWaitForever);
		isPressed = true;
	  }
}


void DroneTaskCallback (cell** maze){
	  //(void) &argument; //remove warnings for unused variables

		float correctedGyroVelocityY = 0;//deg/sec
		float correctedGyroVelocityX = 0;  //deg/sec
		float angularYDisplacement = 0;   //deg
		float angularXDisplacement = 0;  //deg
		float oldGyroVelocityX;
		float oldGyroVelocityY;
		float accelerationX;
		float accelerationY;
	  for(;;)
	  {


	    osSemaphoreAcquire(droneSemaphore ,osWaitForever);

		isPressed = Return_Press();

		oldGyroVelocityY = correctedGyroVelocityY;
		oldGyroVelocityX = correctedGyroVelocityX;

		//physics calculations
		correctedGyroVelocityY = (17.5/1000) * gyroYVal;  //deg/sec     //17.5 is sensitivity
		correctedGyroVelocityX = (17.5/1000) * gyroXVal;  //deg/sec



		accelerationX = (oldGyroVelocityX - correctedGyroVelocityX)/0.3;
		accelerationY = (oldGyroVelocityY - correctedGyroVelocityY)/0.3;


		correctedGyroVelocityY = oldGyroVelocityY + correctedGyroVelocityY;
		correctedGyroVelocityX = oldGyroVelocityX + correctedGyroVelocityX;


		angularYDisplacement = correctedGyroVelocityY * 0.3;   //deg    0.3 = sample rate
		angularXDisplacement = correctedGyroVelocityX * 0.3;  //deg
		//ACCELERATION = change in v / change in time

		//corrected velocity should be old velocity + acceleration * 0.3



		float midX, midY;



		//implement excessive tilt


		//maybe could just pring words
		//print the angular displacement
		printY = (int)angularYDisplacement; // gonna be a lil harder to print a float whoopoo
		printX = (int)angularXDisplacement;



//      using the distance from a line defined by 2 points formula
		if(isPressed!=1 || disruptorPower <= defaultValues.minActivationEnergy || pressedTime >= defaultValues.maxTime){    //disruptorPower > minActivationEnergy

			for(int i = 0; i < numWalls; i++){
				if(walls[i].isHorizontal){
					//double y = (abs((walls[i].endX - walls[i].startX)*(yPos - walls[i].startY) - (xPos - walls[i].startX) * (walls[i].startY - walls[i].startY)))/sqrt(( (walls[i].endX - walls[i].startX) * (walls[i].endX - walls[i].startX)) + ((walls[i].startY - walls[i].startY) * (walls[i].startY - walls[i].startY)));
					if((abs((walls[i].endX - walls[i].startX)*(yPos - walls[i].startY) - (xPos - walls[i].startX) * (walls[i].startY - walls[i].startY)))/sqrt(( (walls[i].endX - walls[i].startX) * (walls[i].endX - walls[i].startX)) + ((walls[i].startY - walls[i].startY) * (walls[i].startY - walls[i].startY))) < 9 && ( abs(walls[i].startX - xPos) < 5 || abs(walls[i].endX - xPos ) < 5 || ((walls[i].startX < xPos) & (xPos < walls[i].endX)))){
						angularXDisplacement = 0;
					}

				}
				else{
					if((abs((walls[i].startX - walls[i].startX)*(yPos - walls[i].startY) - (xPos - walls[i].startX) * (walls[i].endY - walls[i].startY)))/sqrt(( (walls[i].startX - walls[i].startX) * (walls[i].startX - walls[i].startX)) + ((walls[i].endY - walls[i].startY) * (walls[i].endY - walls[i].startY))) < 9 && ( abs(walls[i].startY - yPos) < 5 || abs(walls[i].endY - yPos ) < 5 || ((walls[i].startY < yPos) & (yPos < walls[i].endY)))){
						angularYDisplacement = 0;
					}
				}
			}
		}
//

		if(angularYDisplacement > 150){
			excessiveTilt();
		}
		if(angularXDisplacement > 150){
			excessiveTilt();
		}


		xPos += angularYDisplacement;
		yPos += angularXDisplacement;


	    if(defaultMaze.hardEdged){
	    	if(xPos <= 18){ //left side of maze
	    		xPos = 19;
	    	}
	    	else if(xPos >= (defaultMaze.cellSize*defaultMaze.width + 10)){ //right side of maze
	    		xPos = defaultMaze.cellSize*defaultMaze.width + 9;
	    	}


	    	if(yPos <= 18){ //top of maze
	    		yPos = 19;
	    	}
	    	else if(yPos >= (defaultMaze.cellSize*defaultMaze.height + 10)){ //bottom of maze
	    		yPos = defaultMaze.cellSize*defaultMaze.height + 9;
	    	}
	    }
	    else{ //making sure the user does not leave the screen
			if(xPos>LCD_PIXEL_WIDTH_X){
				xPos = LCD_PIXEL_WIDTH_X -10;
			}
			if(xPos < 10){
				xPos = 10;
			}
			if(yPos>LCD_PIXEL_HEIGHT_Y){
				yPos = LCD_PIXEL_HEIGHT_Y -10;
			}
			if(yPos < 10){
				yPos = 10;
			}
	    }


		for(int i = 0; i < numHoles; i++){
			if(isPressed!=1 || disruptorPower <= defaultValues.minActivationEnergy || pressedTime >= defaultValues.maxTime){
				midX = (holes[i].endX + holes[i].startX)/2;
				midY = (holes[i].endY + holes[i].startY)/2;
				if(((midX - xPos) * (midX - xPos)) + ((midY - yPos) * (midY - yPos)) <= (defaultValues.holeDiameter * defaultValues.holeDiameter)){
					hitHole();
				}
			}
		}


		//keeping track of the user and the waypoints they have made it through
		if(sqrt(((intPair1.x - xPos) * (intPair1.x - xPos)) + (intPair1.y - yPos) * (intPair1.y - yPos)) <= defaultValues.waypointDiameter/2){
			waypoint1Hit = true;
		}

		if((sqrt(((intPair2.x - xPos) * (intPair2.x - xPos)) + (intPair2.y - yPos) * (intPair2.y - yPos)) <= defaultValues.waypointDiameter/2) & waypoint1Hit){
			waypoint2Hit = true;
		}

		if((sqrt(((intPair3.x - xPos) * (intPair3.x - xPos)) + (intPair3.y - yPos) * (intPair3.y - yPos)) <= defaultValues.waypointDiameter/2) & waypoint1Hit & waypoint2Hit){
			waypoint3Hit = true;
		}

		if((sqrt(((intPair4.x - xPos) * (intPair4.x - xPos)) + (intPair4.y - yPos) * (intPair4.y - yPos)) <= defaultValues.waypointDiameter/2) & waypoint1Hit & waypoint2Hit & waypoint3Hit){
			waypoint4Hit = true;
		}


		if(isPressed){
			pressedTime += 0.3; //0.3 is how often this thread is called
			if(disruptorPower>0){
				disruptorPower -= 150;
			}
		}
		else{
			pressedTime = 0; //pressed time resets every time the disruptor is turned off
			if(disruptorPower<defaultValues.MaxEnergy){
				disruptorPower += 150;
			}
		}

		osSemaphoreRelease(LCDSemaphore);
		//array which stores most recent positions and if the most recent like 5 or 10 are in a direction keep it going that way

		//can use similar logic to the draw circle fill logic to see if the ball is within a waypoint



	    //getGyroVelocity() [mdeg/sec]

	    //correctedGyroVelocity() = (sensitivity/1000) * gyroGetVelocity() [deg/sec]

	   // angularDisplacement = correctedGyroVelocity * TAU_gyro [deg]  TAU is the sampling rate in seconds

	    //totalAngleX += angularDisplacement [deg]

	  }
}


void LEDOutputTaskCallback (void *argument){
	  (void) &argument; //remove warnings for unused variables

	  for(;;)
	  {
		osSemaphoreAcquire(	LEDSemaphore ,osWaitForever);

	  }
}

/**
  * @brief Function to update the LCD
  * @param pointer to 2d array of cells which represents the maze
  * @retval None
  */
void LCDUpdateTaskCallback (cell** maze){

	  //(void) &argument; //remove warnings for unused variables
	  for(;;)
	  {
		osSemaphoreAcquire(	LCDSemaphore ,osWaitForever);

				clearScreen();
				if(isPressed && disruptorPower > 0){
					LCD_Draw_Circle_Fill(xPos, yPos, 10, LCD_COLOR_GREEN);
				}
				else{

					LCD_Draw_Circle_Fill(xPos, yPos, 10, LCD_COLOR_BLUE);
				}
				printMaze(maze, 3, 10, 10, defaultMaze.hardEdged, holes, walls);


				//print and keep track of waypoints
				if(waypoint1Hit){
					LCD_Draw_Circle_NoFill(defaultValues.waypointLocation1.x, defaultValues.waypointLocation1.y, defaultValues.waypointDiameter/2, LCD_COLOR_LIGHTGRAY);
					if(waypoint2Hit){
						LCD_Draw_Circle_NoFill(defaultValues.waypointLocation2.x, defaultValues.waypointLocation2.y, defaultValues.waypointDiameter/2, LCD_COLOR_LIGHTGRAY);

						if(waypoint3Hit){
							LCD_Draw_Circle_NoFill(defaultValues.waypointLocation3.x, defaultValues.waypointLocation3.y, defaultValues.waypointDiameter/2, LCD_COLOR_LIGHTGRAY);

							if(waypoint4Hit){
								LCD_Draw_Circle_NoFill(defaultValues.waypointLocation4.x, defaultValues.waypointLocation4.y, defaultValues.waypointDiameter/2, LCD_COLOR_LIGHTGRAY);
								displayScore(time);
							}
							else{
								LCD_Draw_Circle_NoFill(defaultValues.waypointLocation4.x, defaultValues.waypointLocation4.y, defaultValues.waypointDiameter/2, LCD_COLOR_ORANGE);
							}
						}
						else{
							LCD_Draw_Circle_NoFill(defaultValues.waypointLocation3.x, defaultValues.waypointLocation3.y, defaultValues.waypointDiameter/2, LCD_COLOR_ORANGE);
							LCD_Draw_Circle_NoFill(defaultValues.waypointLocation4.x, defaultValues.waypointLocation4.y, defaultValues.waypointDiameter/2, LCD_COLOR_BLUE);
						}
					}
					else{
						LCD_Draw_Circle_NoFill(defaultValues.waypointLocation2.x, defaultValues.waypointLocation2.y, defaultValues.waypointDiameter/2, LCD_COLOR_ORANGE);
						LCD_Draw_Circle_NoFill(defaultValues.waypointLocation3.x, defaultValues.waypointLocation3.y, defaultValues.waypointDiameter/2, LCD_COLOR_BLUE);
						LCD_Draw_Circle_NoFill(defaultValues.waypointLocation4.x, defaultValues.waypointLocation4.y, defaultValues.waypointDiameter/2, LCD_COLOR_BLUE);

					}
				}
				else{
					LCD_Draw_Circle_NoFill(defaultValues.waypointLocation1.x, defaultValues.waypointLocation1.y, defaultValues.waypointDiameter/2, LCD_COLOR_ORANGE);
					LCD_Draw_Circle_NoFill(defaultValues.waypointLocation2.x, defaultValues.waypointLocation2.y, defaultValues.waypointDiameter/2, LCD_COLOR_BLUE);
					LCD_Draw_Circle_NoFill(defaultValues.waypointLocation3.x, defaultValues.waypointLocation3.y, defaultValues.waypointDiameter/2, LCD_COLOR_BLUE);
					LCD_Draw_Circle_NoFill(defaultValues.waypointLocation4.x, defaultValues.waypointLocation4.y, defaultValues.waypointDiameter/2, LCD_COLOR_BLUE);
				}


				//print the time remaining
				int t = time;
				int t2;
				char i;
				int y = 0;
				while (t > 0){
					t2 = t % 10;
					i = (t2 + 48);
					t = t/10;
					LCD_DisplayChar(150-(13*y),240,i);
					y++;
				}

				y = 0;


						//gotta account for printing a negative sign smh


				LCD_DisplayChar(8,270,'x');
				LCD_DisplayChar(25,270,'d');
				LCD_DisplayChar(35,270,'i');
				LCD_DisplayChar(42,270,'s');
				LCD_DisplayChar(54,270,'p');
				LCD_DisplayChar(62,270,'l');
				LCD_DisplayChar(70,270,'a');
				LCD_DisplayChar(82,270,'c');
				LCD_DisplayChar(92,270,'e');
				LCD_DisplayChar(107,270,'m');
				LCD_DisplayChar(121,270,'e');
				LCD_DisplayChar(132,270,'n');
				LCD_DisplayChar(142,270,'t');
				LCD_DisplayChar(149,270,':');


				LCD_DisplayChar(8,290,'y');
				LCD_DisplayChar(25,290,'d');
				LCD_DisplayChar(35,290,'i');
				LCD_DisplayChar(42,290,'s');
				LCD_DisplayChar(54,290,'p');
				LCD_DisplayChar(62,290,'l');
				LCD_DisplayChar(70,290,'a');
				LCD_DisplayChar(82,290,'c');
				LCD_DisplayChar(92,290,'e');
				LCD_DisplayChar(107,290,'m');
				LCD_DisplayChar(121,290,'e');
				LCD_DisplayChar(132,290,'n');
				LCD_DisplayChar(142,290,'t');
				LCD_DisplayChar(149,290,':');


				bool printNegative;
				if(printY < 0){
					printNegative = true;
				}
				else{
					printNegative = false;
				}

				printY = abs(printY);
				if(printY == 0){
					LCD_DisplayChar(190-(13*y),270,'0');
				}
				while (printY != 0){
					t2 = printY % 10;
					i = (t2 + 48);
					printY = printY/10;
					LCD_DisplayChar(190-(13*y),270,i);
					y++;
				}

				if(printNegative){
					LCD_DisplayChar(190-(13*y),270,'-');
				}


				if(printX < 0){
					printNegative = true;
				}
				else{
					printNegative = false;
				}
				printX = abs(printX);

				y = 0;
				if(printX == 0){
					LCD_DisplayChar(190-(13*y),290,'0');
				}

				while (printX != 0){
					t2 = printX % 10;
					i = (t2 + 48);
					printX = printX/10;
					LCD_DisplayChar(190-(13*y),290,i);
					y++;
				}

				if(printNegative){
								//print - sign
					LCD_DisplayChar(190-(13*y),290,'-');
				}
			  }
}

/**
  * @brief Function to free memory from maze, hole, and wall arrays and then end the game
  * @param None
  * @retval None
  */
void endGame(){

	//free memory from both arrays
	gameOver();
}


/**
  * @brief Function to set the default values for the init data structures
  * @param None
  * @retval None
  */
void setDefaultValues(){
	intPair1.x = 50;
	intPair1.y = 50;
	intPair2.x = 130;
	intPair2.y = 50;
	intPair3.x = 130;
	intPair3.y = 130;
	intPair4.x = 50;
	intPair4.y = 130;
	defaultValues.version = 1;
	defaultValues.gravity = 980;
	defaultValues.updateFrequency = 50;
	defaultValues.pinAtCenter = DRONE;
	defaultValues.angleGain = 500;
	defaultValues.maxTime = 5;
	defaultValues.power = 10000;
	defaultValues.minActivationEnergy = 6000;
	defaultValues.MaxEnergy = 15000;
	defaultValues.rechargeRate=1000;
	defaultValues.diameter = 10;
	defaultValues.timeToComplete = 30000;
	defaultValues.cellSize = 12;
	defaultValues.width = 10;
	defaultValues.height = 10;
	defaultValues.wallProbability = 100;
	defaultValues.holeProbability = 200;
	defaultValues.holeDiameter = 11;
	defaultValues.hardEdged = 1;
	defaultValues.numberWaypoints = 4;
	defaultValues.waypointDiameter = 60;
	defaultValues.waypointReuse = 0;
	defaultValues.waypointLocation1 = intPair1;
	defaultValues.waypointLocation2 = intPair2;
	defaultValues.waypointLocation3 = intPair3;
	defaultValues.waypointLocation4 = intPair4;
	defaultMaze.cellSize = 12;
	defaultMaze.hardEdged = 1;
	defaultMaze.height = 15;
	defaultMaze.width = 15;
	defaultMaze.holeDiameter = 11;
	defaultMaze.holeProbability = 200;
	defaultMaze.wallProbability = 100;
}




/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */
//
  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */
//
  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */
//
  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief DMA2D Initialization Function
  * @param None
  * @retval None
  */
static void MX_DMA2D_Init(void)
{

  /* USER CODE BEGIN DMA2D_Init 0 */

  /* USER CODE END DMA2D_Init 0 */

  /* USER CODE BEGIN DMA2D_Init 1 */

  /* USER CODE END DMA2D_Init 1 */
  hdma2d.Instance = DMA2D;
  hdma2d.Init.Mode = DMA2D_M2M;
  hdma2d.Init.ColorMode = DMA2D_OUTPUT_RGB565;
  hdma2d.Init.OutputOffset = 0;
  hdma2d.LayerCfg[1].InputOffset = 0;
  hdma2d.LayerCfg[1].InputColorMode = DMA2D_INPUT_RGB565;
  hdma2d.LayerCfg[1].AlphaMode = DMA2D_NO_MODIF_ALPHA;
  hdma2d.LayerCfg[1].InputAlpha = 0;
  if (HAL_DMA2D_Init(&hdma2d) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_DMA2D_ConfigLayer(&hdma2d, 1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DMA2D_Init 2 */

  /* USER CODE END DMA2D_Init 2 */

}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.ClockSpeed = 100000;
  hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief LTDC Initialization Function
  * @param None
  * @retval None
  */
static void MX_LTDC_Init(void)
{

  /* USER CODE BEGIN LTDC_Init 0 */

  /* USER CODE END LTDC_Init 0 */

  LTDC_LayerCfgTypeDef pLayerCfg = {0};

  /* USER CODE BEGIN LTDC_Init 1 */

  /* USER CODE END LTDC_Init 1 */
  hltdc.Instance = LTDC;
  hltdc.Init.HSPolarity = LTDC_HSPOLARITY_AL;
  hltdc.Init.VSPolarity = LTDC_VSPOLARITY_AL;
  hltdc.Init.DEPolarity = LTDC_DEPOLARITY_AL;
  hltdc.Init.PCPolarity = LTDC_PCPOLARITY_IPC;
  hltdc.Init.HorizontalSync = 9;
  hltdc.Init.VerticalSync = 1;
  hltdc.Init.AccumulatedHBP = 29;
  hltdc.Init.AccumulatedVBP = 3;
  hltdc.Init.AccumulatedActiveW = 269;
  hltdc.Init.AccumulatedActiveH = 323;
  hltdc.Init.TotalWidth = 279;
  hltdc.Init.TotalHeigh = 327;
  hltdc.Init.Backcolor.Blue = 0;
  hltdc.Init.Backcolor.Green = 0;
  hltdc.Init.Backcolor.Red = 0;
  if (HAL_LTDC_Init(&hltdc) != HAL_OK)
  {
    Error_Handler();
  }
  pLayerCfg.WindowX0 = 0;
  pLayerCfg.WindowX1 = 240;
  pLayerCfg.WindowY0 = 0;
  pLayerCfg.WindowY1 = 320;
  pLayerCfg.PixelFormat = LTDC_PIXEL_FORMAT_RGB565;
  pLayerCfg.Alpha = 255;
  pLayerCfg.Alpha0 = 0;
  pLayerCfg.BlendingFactor1 = LTDC_BLENDING_FACTOR1_PAxCA;
  pLayerCfg.BlendingFactor2 = LTDC_BLENDING_FACTOR2_PAxCA;
  pLayerCfg.FBStartAdress = 0xD0000000;
  pLayerCfg.ImageWidth = 240;
  pLayerCfg.ImageHeight = 320;
  pLayerCfg.Backcolor.Blue = 0;
  pLayerCfg.Backcolor.Green = 0;
  pLayerCfg.Backcolor.Red = 0;
  if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LTDC_Init 2 */

  /* USER CODE END LTDC_Init 2 */

}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief SPI5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI5_Init(void)
{

  /* USER CODE BEGIN SPI5_Init 0 */

  /* USER CODE END SPI5_Init 0 */

  /* USER CODE BEGIN SPI5_Init 1 */

  /* USER CODE END SPI5_Init 1 */
  /* SPI5 parameter configuration*/
  hspi5.Instance = SPI5;
  hspi5.Init.Mode = SPI_MODE_MASTER;
  hspi5.Init.Direction = SPI_DIRECTION_2LINES;
  hspi5.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi5.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi5.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi5.Init.NSS = SPI_NSS_SOFT;
  hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi5.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi5.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI5_Init 2 */

  /* USER CODE END SPI5_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/* FMC initialization function */
static void MX_FMC_Init(void)
{

  /* USER CODE BEGIN FMC_Init 0 */

  /* USER CODE END FMC_Init 0 */

  FMC_SDRAM_TimingTypeDef SdramTiming = {0};

  /* USER CODE BEGIN FMC_Init 1 */

  /* USER CODE END FMC_Init 1 */

  /** Perform the SDRAM2 memory initialization sequence
  */
  hsdram2.Instance = FMC_SDRAM_DEVICE;
  /* hsdram2.Init */
  hsdram2.Init.SDBank = FMC_SDRAM_BANK2;
  hsdram2.Init.ColumnBitsNumber = FMC_SDRAM_COLUMN_BITS_NUM_8;
  hsdram2.Init.RowBitsNumber = FMC_SDRAM_ROW_BITS_NUM_12;
  hsdram2.Init.MemoryDataWidth = FMC_SDRAM_MEM_BUS_WIDTH_16;
  hsdram2.Init.InternalBankNumber = FMC_SDRAM_INTERN_BANKS_NUM_4;
  hsdram2.Init.CASLatency = FMC_SDRAM_CAS_LATENCY_1;
  hsdram2.Init.WriteProtection = FMC_SDRAM_WRITE_PROTECTION_DISABLE;
  hsdram2.Init.SDClockPeriod = FMC_SDRAM_CLOCK_DISABLE;
  hsdram2.Init.ReadBurst = FMC_SDRAM_RBURST_DISABLE;
  hsdram2.Init.ReadPipeDelay = FMC_SDRAM_RPIPE_DELAY_0;
  /* SdramTiming */
  SdramTiming.LoadToActiveDelay = 16;
  SdramTiming.ExitSelfRefreshDelay = 16;
  SdramTiming.SelfRefreshTime = 16;
  SdramTiming.RowCycleDelay = 16;
  SdramTiming.WriteRecoveryTime = 16;
  SdramTiming.RPDelay = 16;
  SdramTiming.RCDDelay = 16;

  if (HAL_SDRAM_Init(&hsdram2, &SdramTiming) != HAL_OK)
  {
    Error_Handler( );
  }

  /* USER CODE BEGIN FMC_Init 2 */

  /* USER CODE END FMC_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ACP_RST_GPIO_Port, ACP_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, RDX_Pin|WRX_DCX_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, LD3_Pin|LD4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : NCS_MEMS_SPI_Pin CSX_Pin OTG_FS_PSO_Pin */
  GPIO_InitStruct.Pin = NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : MEMS_INT1_Pin MEMS_INT2_Pin TP_INT1_Pin */
  GPIO_InitStruct.Pin = MEMS_INT1_Pin|MEMS_INT2_Pin|TP_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ACP_RST_Pin */
  GPIO_InitStruct.Pin = ACP_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ACP_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : OTG_FS_OC_Pin */
  GPIO_InitStruct.Pin = OTG_FS_OC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(OTG_FS_OC_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : BOOT1_Pin */
  GPIO_InitStruct.Pin = BOOT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BOOT1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : TE_Pin */
  GPIO_InitStruct.Pin = TE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(TE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RDX_Pin WRX_DCX_Pin */
  GPIO_InitStruct.Pin = RDX_Pin|WRX_DCX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD4_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* init code for USB_HOST */
  MX_USB_HOST_Init();
  /* USER CODE BEGIN 5 */
  /* Infinite loop */


  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END 5 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */


/* USER CODE BEGIN 7 */

/**
  * @brief function to handle the button interrupt
  * @retval None
  */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){

//	osEventFlagsSet(buttonEvent, BUTTON_EVENT_FLAG); //set the event flag for the button
	pressedTime = 0;
	osSemaphoreRelease(buttonSemaphore);
}

/* USER CODE END 7 */
