/*
 * LED_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */


#include <LED_Driver.h>

static GPIO_InitTypeDef GreenLED;
static GPIO_InitTypeDef RedLED;

/**
  * @brief Function to initialize LED peripheral
  * @param NONE
  * @retval None
  */
void initializeLED(uint16_t whichLED){

	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET);

}

/**
  * @brief Function to toggle LED
  * @param the pin for either the green or red LED
  * @retval None
  */
void toggleLED(uint16_t whichLED){
	HAL_GPIO_TogglePin(GPIOG, whichLED);
}

/**
  * @brief Function to disable LED
  * @param the pin for either the green or red LED
  * @retval None
  */
void disableLED(uint16_t whichLED){
	HAL_GPIO_WritePin(GPIOG, whichLED, GPIO_PIN_RESET);
}

/**
  * @brief Function to turn on LED
  * @param the pin for either the green or red LED
  * @retval None
  */
void enableLED(uint16_t whichLED){
	HAL_GPIO_WritePin(GPIOG, whichLED, GPIO_PIN_SET);
}
