#include"ApplicationCode.h"



#define RED GPIO_PIN_14
#define GREEN GPIO_PIN_13
#define BUTTON_PORT GPIOA
#define BUTTON_PIN GPIO_PIN_0


bool ButtonPressed = false; //global variable to store if the button is pressed or not
bool isButtonPressed; //global value to store button pressed state
bool currentGyroValue; //global variable to store gyro value

RNG_HandleTypeDef RNG_Handle;


#if COMPILE_TOUCH_FUNCTIONS == 1
static STMPE811_TouchData StaticTouchData;
#if TOUCH_INTERRUPT_ENABLED == 1
static EXTI_HandleTypeDef LCDTouchIRQ;
void LCDTouchScreenInterruptGPIOInit(void);
#endif // TOUCH_INTERRUPT_ENABLED
#endif // COMPILE_TOUCH_FUNCTIONS


cell* arrayOfWalls;
cell* arrayOfHoles;
int numberOfWalls = 0;
int numberOfHoles = 0;



/**
  * @brief Initialize peripherals
  * @retval None
  */
void Application_Init(){

    LTCD__Init();
	LTCD_Layer_Init(0);
	LCD_Clear(LCD_COLOR_WHITE);
	Gyro_Init();




	RNG_Init(&RNG_Handle);
	//need to call the maze generation function
	//need to initialize all the semiphores and shit
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);

	initializeLED(RED);
	initializeLED(GREEN);
	//deactivate LEDs so they're at known state
	//disableLED(GREEN);
	enableLED(GREEN);
	//disableLED(RED);
	enableLED(RED);
	PWM();

	#if COMPILE_TOUCH_FUNCTIONS == 1

	InitializeLCDTouch();

	// This is the orientation for the board to be direclty up where the buttons are vertically above the screen
	// Top left would be low x value, high y value. Bottom right would be low x value, low y value.
	StaticTouchData.orientation = STMPE811_Orientation_Portrait_2;

	#if TOUCH_INTERRUPT_ENABLED == 1
	LCDTouchScreenInterruptGPIOInit();
	#endif // TOUCH_INTERRUPT_ENABLED

	#endif // COMPILE_TOUCH_FUNCTIONS
	//thread_Init();
}



//not sure how to make a 1d array
cell* getHoleList(cell** maze, int width, int height){

	int numHoles = 0;

	for(int i = 0; i < width; i++){
		for(int j = 0; j < height; j++){
			if(maze[i][j].isHole == 1){
				numHoles++;
			}
		}
	}
	cell *holeArray = malloc(sizeof(cell) * numHoles);

	int index = 0;
	for(int i = 0; i < width; i++){
		for(int j = 0; j < height; j++){
			if(maze[i][j].isHole == 1){
				holeArray[index] = maze[i][j];
				index++;
			}
		}
	}
	numberOfHoles = numHoles;
	arrayOfHoles = holeArray;
	return holeArray;
}


//not sure how to make a 1d array



/**
  * @brief function to make an array of all of the cells which are walls
  * @params maze pointer, width, height (number of cells to sort through)
  * @retval cell* array of cells which are walls
  */
cell* getWallList(cell** maze, int width, int height){

	int numWalls = 0;

	for(int i = 0; i < width; i++){
		for(int j = 0; j < height; j++){
			if(maze[i][j].isWall == 1){
				numWalls++;
			}
		}
	}
	cell *wallArray = malloc(sizeof(cell) * numWalls);

	int index = 0;
	for(int i = 0; i < width; i++){
		for(int j = 0; j < height; j++){
			if(maze[i][j].isWall == 1){
				wallArray[index] = maze[i][j];
				index++;
			}
		}
	}
	numberOfWalls = numWalls;
	arrayOfWalls = wallArray;
	return wallArray;
}


/**
  * @brief Function to generate a maze array
  * @param cell width, width of array and height of array
  * @retval 2d array of cells (maze)
  */
cell** generateMaze(int cellSize, int width, int height, bool hardEdged){
//
////	int cellSize; //(mm)
////	int width; //(cells)
////	int height; //(cells)
	////
	//cell



	//somehow need to make an array of wall cells


	cell **maze = malloc(10 * sizeof *maze);

	float midPointX;
	float midPointY;
	uint32_t rand;
	int randVal;
	//cell maze[width][height];
	int xpos=10;
	int ypos= 10;
	//LCD_Draw_Vertical_Line(10,10,300,LCD_COLOR_MAGENTA);
	//LCD_Draw_Horizontal_Line(10,10,220,LCD_COLOR_MAGENTA);
    if(hardEdged){
		LCD_Draw_Vertical_Line(xpos+1,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Vertical_Line(xpos-1,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,ypos+1,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,ypos-1,(height*6.5*cellSize),LCD_COLOR_MAGENTA);



		LCD_Draw_Horizontal_Line(10,cellSize*width*6.5 + 7,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,cellSize*width*6.5 + 6,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,cellSize*width*6.5 + 8,(width*6.5*cellSize),LCD_COLOR_MAGENTA);


		LCD_Draw_Vertical_Line(cellSize*height*6.5 + 8,10,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Vertical_Line(cellSize*height*6.5 + 7,10,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Vertical_Line(cellSize*height*6.5 + 6,10,(height*6.5*cellSize),LCD_COLOR_MAGENTA);

	//	LCD_Draw_Horizontal_Line((height*6.5*cellSize) + 11,ypos+1,(height*6.5*cellSize),LCD_COLOR_MAGENTA);

		//LCD_Draw_Horizontal_Line(10,ypos-1,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
	//	LCD_Draw_Vertical_Line(xpos+1,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
	//	LCD_Draw_Vertical_Line(xpos-1,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
    }

	for(int i = 0; i < width + 1; i++){
		maze[i] = malloc(10 * sizeof(cell));
		LCD_Draw_Horizontal_Line(10,xpos,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		xpos+=(cellSize*6.5);
	}
	for(int i = 0; i < height + 1; i++){
		LCD_Draw_Vertical_Line(ypos,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		ypos+=(cellSize*6.5);
	}





	for(int i = 0; i < width; i++){
		rand = RNG_GetNum(RNG_Handle);
		for(int j = 0; j < height; j++){
			maze[i][j].startX = (cellSize*6.5*i) + 10;
			maze[i][j].endX = (cellSize*6.5*(i+1)) + 10;
			maze[i][j].startY = (cellSize*6.5*j) + 10;
			maze[i][j].endY = (cellSize*6.5*(1+j)) + 10;
			randVal = rand % 10;
			rand = rand/10;
			if(randVal > 6 && i > 2 && j > 2){
				maze[i][j].isWall = true;
				if(randVal > 8){
					maze[i][j].isHorizontal = true;
					LCD_Draw_Horizontal_Line(maze[i][j].startX,maze[i][j].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
					LCD_Draw_Horizontal_Line(maze[i][j].startX,maze[i][j].startY-1,6.5*cellSize,LCD_COLOR_MAGENTA);
					LCD_Draw_Horizontal_Line(maze[i][j].startX,maze[i][j].startY+1,6.5*cellSize,LCD_COLOR_MAGENTA);
				}
				else{
					LCD_Draw_Vertical_Line(maze[i][j].startX,maze[i][j].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
					LCD_Draw_Vertical_Line(maze[i][j].startX-1,maze[i][j].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
					LCD_Draw_Vertical_Line(maze[i][j].startX+1,maze[i][j].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
					maze[i][j].isHorizontal = false;
				}
			}
			else{
				maze[i][j].isWall = false;
			}
			if(randVal < 2 && i > 2 && j > 2){
				maze[i][j].isHole = true;
				midPointX = (maze[i][j].startX + maze[i][j].endX)/2;
				midPointY = (maze[i][j].startY + maze[i][j].endY)/2;
				draw_hole(10, midPointX, midPointY);
			}
			else{
				maze[i][j].isHole = false;
			}
		}
	}
	return maze;
}

/**
  * @brief Function to be repeatedly called by the LCD task in order to print the maze to the LCD
  * @param the maze array, size of the cells, width of the aray in cells and the height of the array in cells
  * @retval None
  */
void printMaze(cell** maze, int cellSize, int width, int height, bool hardEdged, cell* holes, cell* walls){

	float midPointX;
	float midPointY;
	int xpos=10;
	int ypos= 10;

    if(hardEdged){

		LCD_Draw_Vertical_Line(xpos+1,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Vertical_Line(xpos-1,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,xpos+1,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,xpos-1,(height*6.5*cellSize),LCD_COLOR_MAGENTA);



		LCD_Draw_Horizontal_Line(10,cellSize*width*6.5 + 7,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,cellSize*width*6.5 + 6,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Horizontal_Line(10,cellSize*width*6.5 + 8,(width*6.5*cellSize),LCD_COLOR_MAGENTA);


		LCD_Draw_Vertical_Line(cellSize*height*6.5 + 8,10,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Vertical_Line(cellSize*height*6.5 + 7,10,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		LCD_Draw_Vertical_Line(cellSize*height*6.5 + 6,10,(height*6.5*cellSize),LCD_COLOR_MAGENTA);

    }

	for(int i = 0; i < width + 1; i++){
		LCD_Draw_Horizontal_Line(10,xpos,(height*6.5*cellSize),LCD_COLOR_MAGENTA);
		xpos+=(cellSize*6.5);
	}
	for(int i = 0; i < height + 1; i++){
		LCD_Draw_Vertical_Line(ypos,10,(width*6.5*cellSize),LCD_COLOR_MAGENTA);
		ypos+=(cellSize*6.5);
	}



    for(int i = 0; i < numberOfWalls; i++){
    	if(arrayOfWalls[i].isHorizontal == true){

    		LCD_Draw_Horizontal_Line(arrayOfWalls[i].startX,arrayOfWalls[i].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
    		LCD_Draw_Horizontal_Line(arrayOfWalls[i].startX,arrayOfWalls[i].startY-1,6.5*cellSize,LCD_COLOR_MAGENTA);
    		LCD_Draw_Horizontal_Line(arrayOfWalls[i].startX,arrayOfWalls[i].startY+1,6.5*cellSize,LCD_COLOR_MAGENTA);
    	}
    	else{
    		LCD_Draw_Vertical_Line(arrayOfWalls[i].startX,arrayOfWalls[i].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
    		LCD_Draw_Vertical_Line(arrayOfWalls[i].startX-1,arrayOfWalls[i].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
    		LCD_Draw_Vertical_Line(arrayOfWalls[i].startX+1,arrayOfWalls[i].startY,6.5*cellSize,LCD_COLOR_MAGENTA);
    	}
    }
    for(int i = 0; i < numberOfHoles; i++){
		midPointX = (arrayOfHoles[i].startX + arrayOfHoles[i].endX)/2;
		midPointY = (arrayOfHoles[i].startY + arrayOfHoles[i].endY)/2;
		draw_hole(10, midPointX, midPointY);
    }
}

/**
  * @brief function to check if the button is pressed and return this value
  * @params diameter, xposition, yposition
  * @retval bool
  */
void draw_hole(uint16_t diameter, uint16_t xpos, uint16_t ypos){

	LCD_Draw_Circle_Fill(xpos, ypos, (diameter/2), LCD_COLOR_MAGENTA);

}

void PWM(void){
	for(int i = 0; i < 100; i ++){
		disableLED(GREEN);
	//	HAL_Delay(2);
		disableLED(RED);

		//enableLED(GREEN);
		HAL_Delay(6);
		enableLED(RED);
		enableLED(GREEN);
		HAL_Delay(5);
		disableLED(RED);
		disableLED(GREEN);

		HAL_Delay(6);
		//disableLED(RED);
		//HAL_Delay();
		enableLED(RED);
		enableLED(GREEN);
	//	enableLED(GREEN);

	}

}

/**
  * @brief function to check if the button is pressed and return this value
  * @params none
  * @retval bool
  */
bool Return_Press(){
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET){
		return true;
	}
	else{
		return false;
	}
}



//need semaphore init function
