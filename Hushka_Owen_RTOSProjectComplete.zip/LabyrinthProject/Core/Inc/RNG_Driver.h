
#include "stm32f4xx_hal.h"
#include <stdio.h>


//static RNG_HandleTypeDef RNG_Handle;
//function to init
void RNG_Init(RNG_HandleTypeDef *RNG_Handle);


uint32_t RNG_GetNum(RNG_HandleTypeDef RNG_Handle);

//void RNG_GetStatus(); //or does an interrupt get thrown if there is an error? idk






