#ifndef INC_APPLICATIONCODE_H_
#define INC_APPLICATIONCODE_H_
#include <stdbool.h>
#include "main.h" //not sure if I need this
#include "RNG_Driver.h"
#include "LED_Driver.h"
#include "cmsis_os.h"
#include "LCD_Driver.h"





typedef struct CELL_STRUCT{
	float startX;
	float endX;
	float startY;
	float endY;
	bool isHole;
	bool isWall;
	bool isHorizontal;

}cell;



//
//void Timer_Init();
//void semaphoreInit();
//void thread_Init();
void Application_Init();
bool Return_Press();
cell** generateMaze(int cellSize, int width, int height, bool hardEdged);
void printMaze(cell** maze, int cellSize, int width, int height, bool hardEdged, cell* holes, cell* walls);

void draw_hole(uint16_t diameter, uint16_t xpos, uint16_t ypos);
void PWM(void);
cell* getHoleList(cell** maze, int width, int height);
cell* getWallList(cell** maze, int width, int height);


#endif /* INC_APPLICATIONCODE_H_ */
